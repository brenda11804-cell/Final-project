// -------- CSV → Questions table --------
function loadQATable(csvPath, tbodySelector) {
  const tbody = document.querySelector(tbodySelector);
  if (!tbody) return;

  Papa.parse(csvPath, {
    download: true,
    header: true,
    skipEmptyLines: true,
    complete: (res) => {
      const rows = res.data;
      // Expect headers: Question, Answer  (case-insensitive fallback)
      rows.forEach((row, idx) => {
        const q = row.Question || row.question || '';
        let a = row.Answer || row.answer || '';

        // Enforce “AI respondent” rule: no N/A allowed
        const naLike = String(a).trim().toLowerCase();
        if (!a || naLike === 'n/a' || naLike === 'na' || naLike === 'null' || naLike === 'undefined') {
          a = 'AI respondent: This answer is intentionally provided by the AI. No “N/A” is permitted for this item.';
        }

        // Encourage thoroughness by leaving long text intact
        const tr = document.createElement('tr');
        const tdQ = document.createElement('td');
        const tdA = document.createElement('td');
        tdQ.textContent = q;
        tdA.textContent = a;
        tr.appendChild(tdQ);
        tr.appendChild(tdA);
        tbody.appendChild(tr);
      });
    },
    error: (err) => {
      const row = document.createElement('tr');
      row.innerHTML = `<td colspan="2">Failed to load CSV (${csvPath}). Error: ${err?.message || err}</td>`;
      document.querySelector(tbodySelector).appendChild(row);
    }
  });
}

// -------- Example charts from trial-data.csv --------
function renderExampleCharts(csvPath, { chart1Id, chart2Id }) {
  Papa.parse(csvPath, {
    download: true,
    header: true,
    skipEmptyLines: true,
    complete: (res) => {
      const map = new Map();
      res.data.forEach(r => {
        if (!r.metric) return;
        const k = String(r.metric).trim();
        const v = Number(r.value || 0);
        map.set(k, (map.get(k) || 0) + v);
      });

      // Chart 1: More vs Less
      const more = map.get('use_more') || 0;
      const less = map.get('use_less') || 0;
      const c1 = document.getElementById(chart1Id);
      if (c1) {
        new Chart(c1, {
          type: 'doughnut',
          data: { labels: ['More', 'Less'], datasets: [{ data: [more, less] }] },
          options: { plugins: { legend: { position: 'bottom' } } }
        });
      }

      // Chart 2: posting frequency bins
      const daily = map.get('posts_daily') || 0;
      const weekly = map.get('posts_weekly') || 0;
      const monthly = map.get('posts_monthly') || 0;
      const c2 = document.getElementById(chart2Id);
      if (c2) {
        new Chart(c2, {
          type: 'bar',
          data: {
            labels: ['Daily', 'Weekly', 'Monthly'],
            datasets: [{ label: 'Count', data: [daily, weekly, monthly] }]
          },
          options: {
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
            plugins: { legend: { display: false } }
          }
        });
      }
    },
    error: () => {
      // Graceful no-op if no CSV
    }
  });
}
